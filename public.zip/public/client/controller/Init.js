let client = new Client("185.60.170.80", "4000")
client.loadSensorNamesFromServer();