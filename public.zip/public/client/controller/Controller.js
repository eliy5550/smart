



const removeContent = () => {
    document.getElementById("sensor_content").innerHTML = ""
}





