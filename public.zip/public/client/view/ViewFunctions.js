function loading(){}
function stopLoading(){}
function reset(){}
function showSensor(){}