class DatesAndTimes{
    getDateAndTime(){
        const date = ""
        const time = ""

        return {date , time}

    }
}